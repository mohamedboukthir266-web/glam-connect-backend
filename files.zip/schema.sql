-- ============================================================
--  GlamConnect – PostgreSQL initialization schema
--  Run once: psql -U postgres -d glamconnect_db -f schema.sql
-- ============================================================

-- ─── Extensions ──────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "pgcrypto";  -- gen_random_uuid()

-- ─── ENUM types ──────────────────────────────────────────────
CREATE TYPE user_role           AS ENUM ('CLIENT', 'SALON_ADMIN', 'FREELANCER', 'PLATFORM_ADMIN');
CREATE TYPE appointment_status  AS ENUM ('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED', 'NO_SHOW');
CREATE TYPE specialist_type     AS ENUM ('SALON_EMPLOYEE', 'FREELANCER');

-- ─── users ───────────────────────────────────────────────────
CREATE TABLE users (
    id            UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name     VARCHAR(100) NOT NULL,
    email         VARCHAR(150) NOT NULL UNIQUE,
    phone         VARCHAR(20),
    password_hash VARCHAR(255) NOT NULL,
    role          user_role    NOT NULL DEFAULT 'CLIENT',
    avatar_url    TEXT,
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ─── salons ──────────────────────────────────────────────────
CREATE TABLE salons (
    id           UUID         PRIMARY KEY DEFAULT gen_random_uuid(),
    owner_id     UUID         NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    name         VARCHAR(150) NOT NULL,
    description  TEXT,
    address      VARCHAR(255),
    city         VARCHAR(100),
    phone        VARCHAR(20),
    latitude     NUMERIC(9,6),
    longitude    NUMERIC(9,6),
    rating       NUMERIC(3,2) CHECK (rating BETWEEN 0 AND 5),
    cover_url    TEXT,
    is_active    BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

-- ─── services (what a salon offers) ──────────────────────────
CREATE TABLE services (
    id              UUID          PRIMARY KEY DEFAULT gen_random_uuid(),
    salon_id        UUID          NOT NULL REFERENCES salons(id) ON DELETE CASCADE,
    name            VARCHAR(150)  NOT NULL,
    description     TEXT,
    price           NUMERIC(10,3) NOT NULL CHECK (price >= 0),   -- TND
    duration_minutes INT          NOT NULL CHECK (duration_minutes > 0),
    is_active       BOOLEAN       NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ   NOT NULL DEFAULT NOW()
);

-- ─── specialists (employees or freelancers) ───────────────────
CREATE TABLE specialists (
    id             UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID            REFERENCES users(id) ON DELETE SET NULL,
    salon_id       UUID            REFERENCES salons(id) ON DELETE SET NULL,
    display_name   VARCHAR(100)    NOT NULL,
    bio            TEXT,
    avatar_url     TEXT,
    type           specialist_type NOT NULL,
    rating         NUMERIC(3,2)    CHECK (rating BETWEEN 0 AND 5),
    is_active      BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at     TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

-- ─── appointments ────────────────────────────────────────────
CREATE TABLE appointments (
    id             UUID               PRIMARY KEY DEFAULT gen_random_uuid(),
    client_id      UUID               NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    specialist_id  UUID               NOT NULL REFERENCES specialists(id) ON DELETE RESTRICT,
    service_id     UUID               NOT NULL REFERENCES services(id) ON DELETE RESTRICT,
    salon_id       UUID               NOT NULL REFERENCES salons(id) ON DELETE RESTRICT,
    start_time     TIMESTAMPTZ        NOT NULL,
    end_time       TIMESTAMPTZ        NOT NULL,
    status         appointment_status NOT NULL DEFAULT 'PENDING',
    notes          TEXT,
    price_paid     NUMERIC(10,3),     -- locked at booking time
    created_at     TIMESTAMPTZ        NOT NULL DEFAULT NOW(),
    updated_at     TIMESTAMPTZ        NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_time_order CHECK (end_time > start_time)
);

-- ─── reviews ─────────────────────────────────────────────────
CREATE TABLE reviews (
    id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    appointment_id UUID        NOT NULL UNIQUE REFERENCES appointments(id) ON DELETE CASCADE,
    client_id      UUID        NOT NULL REFERENCES users(id),
    specialist_id  UUID        NOT NULL REFERENCES specialists(id),
    rating         INT         NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment        TEXT,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─── Indexes ──────────────────────────────────────────────────

-- Main booking overlap query: specialist availability window
CREATE INDEX idx_appt_specialist_time
    ON appointments (specialist_id, start_time, end_time)
    WHERE status NOT IN ('CANCELLED');

-- Client schedule listing
CREATE INDEX idx_appt_client
    ON appointments (client_id, start_time DESC);

-- Salon service search
CREATE INDEX idx_services_salon
    ON services (salon_id)
    WHERE is_active = TRUE;

-- Geospatial proximity search (optional: add PostGIS for ST_Distance)
CREATE INDEX idx_salons_city
    ON salons (city)
    WHERE is_active = TRUE;

-- ─── Auto-update updated_at via trigger ───────────────────────
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_users_updated_at    BEFORE UPDATE ON users        FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_salons_updated_at   BEFORE UPDATE ON salons       FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER trg_appt_updated_at     BEFORE UPDATE ON appointments FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- ─── Seed data (dev only) ────────────────────────────────────
-- Platform admin
INSERT INTO users (full_name, email, password_hash, role)
VALUES ('Admin GlamConnect', 'admin@glamconnect.tn',
        '$2a$10$placeholder_bcrypt_hash', 'PLATFORM_ADMIN');
