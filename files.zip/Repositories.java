// ──────────────────────────────────────────────────────────────
//  FILE: .../repository/AppointmentRepository.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.infrastructure.repository;

import com.glamconnect.domain.entity.Appointment;
import com.glamconnect.domain.entity.Appointment.AppointmentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Repository
public interface AppointmentRepository extends JpaRepository<Appointment, UUID> {

    /**
     * ══════════════════════════════════════════════════════════
     *  DOUBLE-BOOKING GUARD — the single most critical query.
     *
     *  An overlap exists when:
     *    existing.startTime  <  requestedEnd
     *    AND
     *    existing.endTime    >  requestedStart
     *
     *  This is Allen's interval overlap condition.
     *  We exclude CANCELLED appointments so a client can rebook
     *  a slot that was previously cancelled.
     * ══════════════════════════════════════════════════════════
     */
    @Query("""
        SELECT COUNT(a) > 0
        FROM   Appointment a
        WHERE  a.specialist.id = :specialistId
          AND  a.status NOT IN (:excludedStatuses)
          AND  a.startTime  < :requestedEnd
          AND  a.endTime    > :requestedStart
        """)
    boolean existsOverlap(
            @Param("specialistId")    UUID specialistId,
            @Param("requestedStart")  Instant requestedStart,
            @Param("requestedEnd")    Instant requestedEnd,
            @Param("excludedStatuses") List<AppointmentStatus> excludedStatuses
    );

    /** Client's own appointments, most recent first */
    Page<Appointment> findByClientIdOrderByStartTimeDesc(UUID clientId, Pageable pageable);

    /** All appointments for a salon — used by salon admin dashboard */
    @Query("""
        SELECT a FROM Appointment a
        WHERE  a.salon.id = :salonId
          AND  a.startTime BETWEEN :from AND :to
        ORDER BY a.startTime ASC
        """)
    List<Appointment> findBySalonAndDateRange(
            @Param("salonId") UUID salonId,
            @Param("from")    Instant from,
            @Param("to")      Instant to
    );

    /** Upcoming appointments for a specialist */
    @Query("""
        SELECT a FROM Appointment a
        WHERE  a.specialist.id = :specialistId
          AND  a.startTime >= :now
          AND  a.status IN ('PENDING', 'CONFIRMED')
        ORDER BY a.startTime ASC
        """)
    List<Appointment> findUpcomingBySpecialist(
            @Param("specialistId") UUID specialistId,
            @Param("now")          Instant now
    );
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../repository/SalonRepository.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.infrastructure.repository;

import com.glamconnect.domain.entity.Salon;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface SalonRepository extends JpaRepository<Salon, UUID> {

    Page<Salon> findByIsActiveTrueOrderByRatingDesc(Pageable pageable);

    Page<Salon> findByCityIgnoreCaseAndIsActiveTrue(String city, Pageable pageable);

    @Query("""
        SELECT s FROM Salon s
        WHERE  s.isActive = TRUE
          AND  (:city IS NULL OR LOWER(s.city) = LOWER(:city))
          AND  (:name IS NULL OR LOWER(s.name) LIKE LOWER(CONCAT('%', :name, '%')))
        ORDER BY s.rating DESC NULLS LAST
        """)
    Page<Salon> search(
            @Param("city") String city,
            @Param("name") String name,
            Pageable pageable
    );
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../repository/UserRepository.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.infrastructure.repository;

import com.glamconnect.domain.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

@Repository
public interface UserRepository extends JpaRepository<User, UUID> {
    Optional<User> findByEmail(String email);
    boolean existsByEmail(String email);
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../repository/BeautyServiceRepository.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.infrastructure.repository;

import com.glamconnect.domain.entity.BeautyService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface BeautyServiceRepository extends JpaRepository<BeautyService, UUID> {
    List<BeautyService> findBySalonIdAndIsActiveTrue(UUID salonId);
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../repository/SpecialistRepository.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.infrastructure.repository;

import com.glamconnect.domain.entity.Specialist;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface SpecialistRepository extends JpaRepository<Specialist, UUID> {
    List<Specialist> findBySalonIdAndIsActiveTrue(UUID salonId);
}
