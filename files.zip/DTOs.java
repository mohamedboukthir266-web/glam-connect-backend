// ──────────────────────────────────────────────────────────────
//  FILE: .../application/dto/BookingRequest.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.application.dto;

import jakarta.validation.constraints.*;

import java.time.Instant;
import java.util.UUID;

/**
 * Request body for POST /bookings.
 * The client sends this; the server computes endTime from service duration.
 */
public record BookingRequest(

    @NotNull(message = "Specialist ID is required")
    UUID specialistId,

    @NotNull(message = "Service ID is required")
    UUID serviceId,

    @NotNull(message = "Salon ID is required")
    UUID salonId,

    /**
     * Desired start time for the appointment.
     * Must be at least 30 minutes in the future to allow preparation time.
     */
    @NotNull(message = "Start time is required")
    @Future(message = "Appointment must be scheduled in the future")
    Instant startTime,

    @Size(max = 500, message = "Notes must not exceed 500 characters")
    String notes
) {}


// ──────────────────────────────────────────────────────────────
//  FILE: .../application/dto/AppointmentResponse.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.application.dto;

import com.glamconnect.domain.entity.Appointment.AppointmentStatus;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;

/** Read-only view returned to clients. No entity internals exposed. */
public record AppointmentResponse(
    UUID id,
    UUID clientId,
    String clientFullName,
    UUID specialistId,
    String specialistDisplayName,
    UUID serviceId,
    String serviceName,
    int serviceDurationMinutes,
    UUID salonId,
    String salonName,
    Instant startTime,
    Instant endTime,
    AppointmentStatus status,
    BigDecimal pricePaid,
    String notes,
    Instant createdAt
) {}


// ──────────────────────────────────────────────────────────────
//  FILE: .../application/dto/SalonResponse.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.application.dto;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

public record SalonResponse(
    UUID id,
    String name,
    String description,
    String address,
    String city,
    String phone,
    BigDecimal latitude,
    BigDecimal longitude,
    BigDecimal rating,
    String coverUrl,
    List<ServiceSummary> services
) {
    public record ServiceSummary(
        UUID id,
        String name,
        BigDecimal price,
        int durationMinutes
    ) {}
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../application/dto/SalonFilterRequest.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.application.dto;

/** Query parameters for GET /salons */
public record SalonFilterRequest(
    String city,
    String name,
    Integer page,     // default 0
    Integer size      // default 20
) {}


// ──────────────────────────────────────────────────────────────
//  FILE: .../application/dto/AuthRequest.java & AuthResponse.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.application.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record AuthRequest(
    @NotBlank @Email String email,
    @NotBlank @Size(min = 8) String password
) {}


package com.glamconnect.application.dto;

public record AuthResponse(
    String accessToken,
    String tokenType,
    long expiresInMs
) {
    public static AuthResponse of(String token, long expiresInMs) {
        return new AuthResponse(token, "Bearer", expiresInMs);
    }
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../application/mapper/AppointmentMapper.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.application.mapper;

import com.glamconnect.application.dto.AppointmentResponse;
import com.glamconnect.domain.entity.Appointment;
import org.mapstruct.*;

@Mapper(componentModel = "spring")
public interface AppointmentMapper {

    @Mapping(target = "clientId",              source = "client.id")
    @Mapping(target = "clientFullName",        source = "client.fullName")
    @Mapping(target = "specialistId",          source = "specialist.id")
    @Mapping(target = "specialistDisplayName", source = "specialist.displayName")
    @Mapping(target = "serviceId",             source = "service.id")
    @Mapping(target = "serviceName",           source = "service.name")
    @Mapping(target = "serviceDurationMinutes",source = "service.durationMinutes")
    @Mapping(target = "salonId",               source = "salon.id")
    @Mapping(target = "salonName",             source = "salon.name")
    AppointmentResponse toResponse(Appointment appointment);
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../application/mapper/SalonMapper.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.application.mapper;

import com.glamconnect.application.dto.SalonResponse;
import com.glamconnect.domain.entity.BeautyService;
import com.glamconnect.domain.entity.Salon;
import org.mapstruct.*;

import java.util.List;

@Mapper(componentModel = "spring")
public interface SalonMapper {

    @Mapping(target = "services", source = "services")
    SalonResponse toResponse(Salon salon);

    List<SalonResponse> toResponseList(List<Salon> salons);

    @Mapping(target = "durationMinutes", source = "durationMinutes")
    SalonResponse.ServiceSummary toServiceSummary(BeautyService service);
}
