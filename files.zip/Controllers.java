// ──────────────────────────────────────────────────────────────
//  FILE: .../presentation/controller/AppointmentController.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.presentation.controller;

import com.glamconnect.application.dto.AppointmentResponse;
import com.glamconnect.application.dto.BookingRequest;
import com.glamconnect.application.service.AppointmentService;
import com.glamconnect.domain.entity.User;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping
@RequiredArgsConstructor
@Tag(name = "Appointments", description = "Booking management endpoints")
@SecurityRequirement(name = "Bearer Authentication")
public class AppointmentController {

    private final AppointmentService appointmentService;

    // ── POST /bookings ─────────────────────────────────────────
    @PostMapping("/bookings")
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(
        summary     = "Book a new appointment",
        description = "Creates an appointment for the authenticated client. " +
                      "Returns 409 CONFLICT if the specialist's slot is taken."
    )
    public ResponseEntity<AppointmentResponse> bookAppointment(
            @Valid @RequestBody BookingRequest request,
            @AuthenticationPrincipal User currentUser
    ) {
        AppointmentResponse response =
                appointmentService.bookAppointment(request, currentUser.getId());
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // ── GET /my-appointments ───────────────────────────────────
    @GetMapping("/my-appointments")
    @Operation(
        summary     = "Get my appointments",
        description = "Returns a paginated list of the current client's appointments, " +
                      "most recent first."
    )
    public ResponseEntity<Page<AppointmentResponse>> getMyAppointments(
            @AuthenticationPrincipal User currentUser,
            @RequestParam(defaultValue = "0")  int page,
            @RequestParam(defaultValue = "10") int size
    ) {
        return ResponseEntity.ok(
                appointmentService.getMyAppointments(currentUser.getId(), page, size)
        );
    }

    // ── GET /bookings/{id} ────────────────────────────────────
    @GetMapping("/bookings/{id}")
    @Operation(summary = "Get a single appointment by ID")
    public ResponseEntity<AppointmentResponse> getById(
            @PathVariable UUID id,
            @AuthenticationPrincipal User currentUser
    ) {
        return ResponseEntity.ok(
                appointmentService.getAppointmentById(id, currentUser.getId())
        );
    }

    // ── DELETE /bookings/{id} (soft-cancel) ───────────────────
    @DeleteMapping("/bookings/{id}")
    @Operation(summary = "Cancel an appointment")
    public ResponseEntity<AppointmentResponse> cancelAppointment(
            @PathVariable UUID id,
            @AuthenticationPrincipal User currentUser
    ) {
        return ResponseEntity.ok(
                appointmentService.cancelAppointment(id, currentUser.getId())
        );
    }
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../presentation/controller/SalonController.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.presentation.controller;

import com.glamconnect.application.dto.SalonResponse;
import com.glamconnect.application.service.SalonService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/salons")
@RequiredArgsConstructor
@Tag(name = "Salons", description = "Discover beauty salons in Tunisia")
public class SalonController {

    private final SalonService salonService;

    /**
     * GET /salons
     * Filters: ?city=Tunis&name=glam&page=0&size=20
     * No authentication required — public endpoint.
     */
    @GetMapping
    @Operation(
        summary     = "List all salons",
        description = "Returns a paginated list of active salons. " +
                      "Optionally filter by city or partial name. Sorted by rating."
    )
    public ResponseEntity<Page<SalonResponse>> listSalons(
            @RequestParam(required = false)            String city,
            @RequestParam(required = false)            String name,
            @RequestParam(defaultValue = "0")          int page,
            @RequestParam(defaultValue = "20")         int size
    ) {
        return ResponseEntity.ok(salonService.search(city, name, page, size));
    }

    /**
     * GET /salons/{id}
     * Returns full salon detail including services list.
     */
    @GetMapping("/{id}")
    @Operation(summary = "Get salon details", description = "Returns a salon with its full service menu.")
    public ResponseEntity<SalonResponse> getSalon(@PathVariable UUID id) {
        return ResponseEntity.ok(salonService.getById(id));
    }
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../presentation/controller/AuthController.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.presentation.controller;

import com.glamconnect.application.dto.AuthRequest;
import com.glamconnect.application.dto.AuthResponse;
import com.glamconnect.application.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login")
    @Operation(summary = "Authenticate and receive a JWT")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody AuthRequest request) {
        return ResponseEntity.ok(authService.login(request));
    }

    @PostMapping("/register")
    @Operation(summary = "Register a new client account")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody AuthRequest request) {
        return ResponseEntity.ok(authService.register(request));
    }
}


// ──────────────────────────────────────────────────────────────
//  FILE: .../presentation/exception/GlobalExceptionHandler.java
// ──────────────────────────────────────────────────────────────
package com.glamconnect.presentation.exception;

import com.glamconnect.application.service.AppointmentService.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.net.URI;
import java.time.Instant;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * Centralised error handling using RFC 7807 ProblemDetail (Spring 6 native).
 * All error responses share the same shape — easy to parse on the frontend.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(BookingConflictException.class)
    ProblemDetail handleConflict(BookingConflictException ex) {
        ProblemDetail pd = ProblemDetail.forStatus(HttpStatus.CONFLICT);
        pd.setType(URI.create("https://glamconnect.tn/errors/booking-conflict"));
        pd.setTitle("Booking conflict");
        pd.setDetail(ex.getMessage());
        pd.setProperty("timestamp", Instant.now());
        return pd;
    }

    @ExceptionHandler(EntityNotFoundException.class)
    ProblemDetail handleNotFound(EntityNotFoundException ex) {
        ProblemDetail pd = ProblemDetail.forStatus(HttpStatus.NOT_FOUND);
        pd.setTitle("Resource not found");
        pd.setDetail(ex.getMessage());
        pd.setProperty("timestamp", Instant.now());
        return pd;
    }

    @ExceptionHandler(AccessDeniedException.class)
    ProblemDetail handleAccessDenied(AccessDeniedException ex) {
        ProblemDetail pd = ProblemDetail.forStatus(HttpStatus.FORBIDDEN);
        pd.setTitle("Access denied");
        pd.setDetail(ex.getMessage());
        pd.setProperty("timestamp", Instant.now());
        return pd;
    }

    @ExceptionHandler(IllegalArgumentException.class)
    ProblemDetail handleBadRequest(IllegalArgumentException ex) {
        ProblemDetail pd = ProblemDetail.forStatus(HttpStatus.BAD_REQUEST);
        pd.setTitle("Invalid request");
        pd.setDetail(ex.getMessage());
        pd.setProperty("timestamp", Instant.now());
        return pd;
    }

    /** Bean Validation errors — returns field-level error map */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    ProblemDetail handleValidation(MethodArgumentNotValidException ex) {
        Map<String, String> errors = ex.getBindingResult().getFieldErrors().stream()
                .collect(Collectors.toMap(
                        FieldError::getField,
                        fe -> fe.getDefaultMessage() == null ? "Invalid value" : fe.getDefaultMessage(),
                        (a, b) -> a   // keep first if duplicate field
                ));
        ProblemDetail pd = ProblemDetail.forStatus(HttpStatus.UNPROCESSABLE_ENTITY);
        pd.setTitle("Validation failed");
        pd.setDetail("One or more fields are invalid.");
        pd.setProperty("errors", errors);
        pd.setProperty("timestamp", Instant.now());
        return pd;
    }
}
