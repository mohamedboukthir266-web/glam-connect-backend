# GlamConnect API — Developer Guide

## Project Structure

```
glamconnect-api/
├── pom.xml
└── src/main/
    ├── java/com/glamconnect/
    │   │
    │   ├── GlamConnectApplication.java        ← Entry point + UserDetailsService bean
    │   │
    │   ├── domain/
    │   │   └── entity/
    │   │       ├── User.java                  ← Implements UserDetails (CLIENT, SALON_ADMIN…)
    │   │       ├── Salon.java
    │   │       ├── BeautyService.java         ← "services" table (name/price/duration)
    │   │       ├── Specialist.java            ← Employee or freelancer
    │   │       └── Appointment.java           ← Core booking entity
    │   │
    │   ├── application/
    │   │   ├── dto/
    │   │   │   ├── BookingRequest.java        ← POST /bookings payload + @Future validation
    │   │   │   ├── AppointmentResponse.java   ← Read-only appointment view
    │   │   │   ├── SalonResponse.java         ← Salon + embedded service list
    │   │   │   ├── SalonFilterRequest.java
    │   │   │   ├── AuthRequest.java
    │   │   │   └── AuthResponse.java          ← JWT token response
    │   │   │
    │   │   ├── mapper/
    │   │   │   ├── AppointmentMapper.java     ← MapStruct: Appointment → AppointmentResponse
    │   │   │   └── SalonMapper.java
    │   │   │
    │   │   └── service/
    │   │       ├── AppointmentService.java    ★ CORE — overlap check + booking logic
    │   │       ├── SalonService.java          ← Search/filter salons
    │   │       └── AuthService.java           ← register + login → JWT
    │   │
    │   ├── infrastructure/
    │   │   ├── repository/
    │   │   │   ├── AppointmentRepository.java ★ existsOverlap() — Allen's interval query
    │   │   │   ├── SalonRepository.java       ← city/name search
    │   │   │   ├── UserRepository.java
    │   │   │   ├── BeautyServiceRepository.java
    │   │   │   └── SpecialistRepository.java
    │   │   │
    │   │   └── security/
    │   │       ├── TokenService.java          ← JJWT 0.12 sign + validate
    │   │       ├── JwtAuthenticationFilter.java
    │   │       └── SecurityConfig.java        ← Spring Security, public routes, 401 handler
    │   │
    │   └── presentation/
    │       ├── controller/
    │       │   ├── AppointmentController.java  ← POST /bookings · GET /my-appointments
    │       │   ├── SalonController.java        ← GET /salons
    │       │   └── AuthController.java         ← POST /auth/login · /register
    │       │
    │       └── exception/
    │           └── GlobalExceptionHandler.java ← RFC 7807 ProblemDetail error responses
    │
    └── resources/
        ├── application.yml
        └── db/
            └── schema.sql                      ← PostgreSQL DDL + indexes + trigger
```

---

## API Endpoints

| Method | Path                  | Auth?  | Description                          |
|--------|-----------------------|--------|--------------------------------------|
| POST   | /auth/register        | No     | Create client account, returns JWT   |
| POST   | /auth/login           | No     | Authenticate, returns JWT            |
| GET    | /salons               | No     | List salons (filter: city, name)     |
| GET    | /salons/{id}          | No     | Get single salon + services          |
| POST   | /bookings             | Yes    | Book a new appointment               |
| GET    | /my-appointments      | Yes    | Client's appointment history         |
| GET    | /bookings/{id}        | Yes    | Get appointment detail               |
| DELETE | /bookings/{id}        | Yes    | Cancel appointment (soft-delete)     |

Base path: `http://localhost:8080/api/v1`

Swagger UI: `http://localhost:8080/api/v1/swagger-ui.html`

---

## Double-Booking Prevention Logic

The overlap detection uses **Allen's interval algebra**:

```
Two intervals A and B overlap if:
    A.start < B.end   AND   A.end > B.start
```

In JPQL (AppointmentRepository):
```java
a.startTime < :requestedEnd
AND a.endTime > :requestedStart
```

CANCELLED appointments are excluded — a cancelled slot can be rebooked.

The `endTime` is computed server-side:
```java
Instant endTime = startTime.plus(service.getDurationMinutes(), ChronoUnit.MINUTES);
```

For high-concurrency production load, add `SELECT ... FOR UPDATE` on the specialist row or upgrade to PostgreSQL SERIALIZABLE isolation.

---

## Local Setup

```bash
# 1. Create database
psql -U postgres -c "CREATE DATABASE glamconnect_db;"
psql -U postgres -d glamconnect_db -f src/main/resources/db/schema.sql

# 2. Set environment variables (or edit application.yml)
export DB_USERNAME=postgres
export DB_PASSWORD=postgres
export JWT_SECRET="YourSuperSecretKeyAtLeast32CharactersLong"

# 3. Run
./mvnw spring-boot:run
```

---

## Error Response Shape (RFC 7807)

All errors return a consistent `ProblemDetail` JSON:

```json
{
  "status": 409,
  "type": "https://glamconnect.tn/errors/booking-conflict",
  "title": "Booking conflict",
  "detail": "Specialist 'Rania Ben Ali' is not available between 2024-06-15T10:00:00Z and 2024-06-15T11:00:00Z.",
  "timestamp": "2024-06-15T09:45:00Z"
}
```

Validation errors additionally include a field-level `errors` map.

---

## Technology Choices

| Concern              | Choice                      | Reason                                     |
|----------------------|-----------------------------|--------------------------------------------|
| Auth                 | Spring Security + JWT       | Stateless, scales horizontally             |
| ORM                  | Spring Data JPA (Hibernate) | Type-safe queries, PostgreSQL-native       |
| Mapping              | MapStruct                   | Compile-time, zero reflection overhead     |
| Password hashing     | BCrypt cost=12              | Industry standard, configurable rounds     |
| Error format         | RFC 7807 ProblemDetail      | Standard, easy to parse on frontend        |
| ID type              | UUID v4                     | No sequential guessing, globally unique    |
| Price storage        | NUMERIC(10,3)               | Exact TND precision, no float rounding     |
| Time storage         | TIMESTAMPTZ / Instant       | Timezone-aware, consistent across regions  |
