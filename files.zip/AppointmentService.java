package com.glamconnect.application.service;

import com.glamconnect.application.dto.AppointmentResponse;
import com.glamconnect.application.dto.BookingRequest;
import com.glamconnect.application.mapper.AppointmentMapper;
import com.glamconnect.domain.entity.Appointment;
import com.glamconnect.domain.entity.Appointment.AppointmentStatus;
import com.glamconnect.domain.entity.BeautyService;
import com.glamconnect.domain.entity.Salon;
import com.glamconnect.domain.entity.Specialist;
import com.glamconnect.domain.entity.User;
import com.glamconnect.infrastructure.repository.AppointmentRepository;
import com.glamconnect.infrastructure.repository.BeautyServiceRepository;
import com.glamconnect.infrastructure.repository.SalonRepository;
import com.glamconnect.infrastructure.repository.SpecialistRepository;
import com.glamconnect.infrastructure.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.UUID;

/**
 * ══════════════════════════════════════════════════════════════
 *  AppointmentService — Core booking engine for GlamConnect
 *
 *  Key responsibilities:
 *   1. Validate booking request (entity existence, time sanity)
 *   2. Compute endTime = startTime + service.durationMinutes
 *   3. Atomically check for specialist time-slot overlap
 *   4. Persist appointment with locked price
 *   5. Provide client schedule retrieval
 * ══════════════════════════════════════════════════════════════
 */
@Service
@RequiredArgsConstructor
@Slf4j
@Transactional(readOnly = true)
public class AppointmentService {

    /**
     * Statuses that "occupy" a time slot.
     * CANCELLED appointments free their slot for rebooking.
     */
    private static final List<AppointmentStatus> BLOCKING_STATUSES = List.of(
            AppointmentStatus.PENDING,
            AppointmentStatus.CONFIRMED
    );

    /** Minimum notice before a booking: 30 minutes from now. */
    private static final long MIN_ADVANCE_MINUTES = 30;

    private final AppointmentRepository  appointmentRepository;
    private final BeautyServiceRepository serviceRepository;
    private final SpecialistRepository    specialistRepository;
    private final SalonRepository         salonRepository;
    private final UserRepository          userRepository;
    private final AppointmentMapper       appointmentMapper;

    // ──────────────────────────────────────────────────────────
    //  CREATE BOOKING
    // ──────────────────────────────────────────────────────────

    /**
     * Books a new appointment.
     *
     * <p>The method is {@code @Transactional} (read-write) and uses a
     * database-level overlap check that is safe under concurrent load,
     * provided PostgreSQL's default READ COMMITTED isolation is used
     * together with the unique partial index on (specialist_id, time range).
     *
     * <p>For production, consider upgrading to SERIALIZABLE or adding a
     * SELECT ... FOR UPDATE on the specialist row if contention is high.
     *
     * @param request  validated booking payload
     * @param clientId UUID of the authenticated client
     * @return fully mapped {@link AppointmentResponse}
     * @throws BookingConflictException  if the specialist is unavailable
     * @throws IllegalArgumentException  if startTime is too soon
     */
    @Transactional
    public AppointmentResponse bookAppointment(BookingRequest request, UUID clientId) {

        // ── 1. Enforce minimum advance notice ─────────────────
        Instant minAllowedStart = Instant.now().plus(MIN_ADVANCE_MINUTES, ChronoUnit.MINUTES);
        if (request.startTime().isBefore(minAllowedStart)) {
            throw new IllegalArgumentException(
                "Appointments must be booked at least " + MIN_ADVANCE_MINUTES
                + " minutes in advance. Requested: " + request.startTime());
        }

        // ── 2. Load referenced entities (fail-fast with clear messages) ─
        User client = userRepository.findById(clientId)
                .orElseThrow(() -> new EntityNotFoundException("User", clientId));

        BeautyService service = serviceRepository.findById(request.serviceId())
                .filter(BeautyService::isActive)
                .orElseThrow(() -> new EntityNotFoundException("Service", request.serviceId()));

        Specialist specialist = specialistRepository.findById(request.specialistId())
                .filter(Specialist::isActive)
                .orElseThrow(() -> new EntityNotFoundException("Specialist", request.specialistId()));

        Salon salon = salonRepository.findById(request.salonId())
                .filter(Salon::isActive)
                .orElseThrow(() -> new EntityNotFoundException("Salon", request.salonId()));

        // ── 3. Compute time window ─────────────────────────────
        Instant startTime = request.startTime();
        Instant endTime   = startTime.plus(service.getDurationMinutes(), ChronoUnit.MINUTES);

        log.debug("Checking availability for specialist {} from {} to {}",
                  specialist.getId(), startTime, endTime);

        // ── 4. DOUBLE-BOOKING CHECK ────────────────────────────
        //
        //  Allen's interval overlap: A overlaps B iff
        //    A.start < B.end  AND  A.end > B.start
        //
        //  We pass CANCELLED to the exclude list; only PENDING and
        //  CONFIRMED appointments block the slot.
        //
        boolean hasConflict = appointmentRepository.existsOverlap(
                specialist.getId(),
                startTime,
                endTime,
                List.of(AppointmentStatus.CANCELLED)   // statuses to EXCLUDE from the check
        );

        if (hasConflict) {
            log.warn("Booking conflict for specialist {} at {}", specialist.getId(), startTime);
            throw new BookingConflictException(
                "Specialist '" + specialist.getDisplayName() + "' is not available "
                + "between " + startTime + " and " + endTime
                + ". Please choose a different time slot.");
        }

        // ── 5. Persist appointment ─────────────────────────────
        Appointment appointment = Appointment.builder()
                .client(client)
                .specialist(specialist)
                .service(service)
                .salon(salon)
                .startTime(startTime)
                .endTime(endTime)
                .status(AppointmentStatus.PENDING)
                .pricePaid(service.getPrice())   // lock price at booking time
                .notes(request.notes())
                .build();

        Appointment saved = appointmentRepository.save(appointment);
        log.info("Appointment {} created for client {} with specialist {}",
                 saved.getId(), clientId, specialist.getId());

        return appointmentMapper.toResponse(saved);
    }

    // ──────────────────────────────────────────────────────────
    //  CANCEL BOOKING
    // ──────────────────────────────────────────────────────────

    @Transactional
    public AppointmentResponse cancelAppointment(UUID appointmentId, UUID requestingUserId) {
        Appointment appointment = appointmentRepository.findById(appointmentId)
                .orElseThrow(() -> new EntityNotFoundException("Appointment", appointmentId));

        // Only the booking client or a platform admin may cancel
        boolean isOwner = appointment.getClient().getId().equals(requestingUserId);
        if (!isOwner) {
            throw new AccessDeniedException("You are not allowed to cancel this appointment.");
        }

        if (appointment.getStatus() == AppointmentStatus.COMPLETED) {
            throw new IllegalStateException("Cannot cancel a completed appointment.");
        }
        if (appointment.getStatus() == AppointmentStatus.CANCELLED) {
            throw new IllegalStateException("Appointment is already cancelled.");
        }

        appointment.setStatus(AppointmentStatus.CANCELLED);
        return appointmentMapper.toResponse(appointmentRepository.save(appointment));
    }

    // ──────────────────────────────────────────────────────────
    //  READ: CLIENT SCHEDULE
    // ──────────────────────────────────────────────────────────

    /**
     * Returns a paginated list of the authenticated client's appointments,
     * ordered most-recent first.
     */
    public Page<AppointmentResponse> getMyAppointments(UUID clientId, int page, int size) {
        PageRequest pageable = PageRequest.of(page, size);
        return appointmentRepository
                .findByClientIdOrderByStartTimeDesc(clientId, pageable)
                .map(appointmentMapper::toResponse);
    }

    // ──────────────────────────────────────────────────────────
    //  READ: SINGLE APPOINTMENT
    // ──────────────────────────────────────────────────────────

    public AppointmentResponse getAppointmentById(UUID id, UUID requestingUserId) {
        Appointment appointment = appointmentRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Appointment", id));

        // clients can only see their own; admins see all (add role check as needed)
        if (!appointment.getClient().getId().equals(requestingUserId)) {
            throw new AccessDeniedException("Access denied.");
        }

        return appointmentMapper.toResponse(appointment);
    }

    // ──────────────────────────────────────────────────────────
    //  Inner exception types (can be extracted to own files)
    // ──────────────────────────────────────────────────────────

    public static class BookingConflictException extends RuntimeException {
        public BookingConflictException(String message) { super(message); }
    }

    public static class EntityNotFoundException extends RuntimeException {
        public EntityNotFoundException(String entity, UUID id) {
            super(entity + " not found with id: " + id);
        }
    }

    public static class AccessDeniedException extends RuntimeException {
        public AccessDeniedException(String message) { super(message); }
    }
}
